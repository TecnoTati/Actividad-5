import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class SortingGUI extends JFrame {
    private JTextField campoTamanoArreglo;
    private JTextArea areaSalida;
    private JButton botonGenerar, botonOrdenamientoBurbuja, botonOrdenamientoInsercion, botonOrdenamientoSeleccion, botonOrdenamientoShell, botonOrdenamientoHeap, botonOrdenamientoQuick;
    private int[] arreglo;

    public SortingGUI() {
        setTitle("Algoritmos de Ordenamiento");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        campoTamanoArreglo = new JTextField(5);
        areaSalida = new JTextArea(10, 30);
        botonGenerar = new JButton("Generar Arreglo");
        botonOrdenamientoBurbuja = new JButton("Ordenamiento Burbuja");
        botonOrdenamientoInsercion = new JButton("Ordenamiento Inserción");
        botonOrdenamientoSeleccion = new JButton("Ordenamiento Selección");
        botonOrdenamientoShell = new JButton("Ordenamiento Shell");
        botonOrdenamientoHeap = new JButton("Ordenamiento Heap");
        botonOrdenamientoQuick = new JButton("Ordenamiento Quick");

        JPanel panel = new JPanel();
        panel.add(new JLabel("Tamaño del Arreglo:"));
        panel.add(campoTamanoArreglo);
        panel.add(botonGenerar);
        panel.add(botonOrdenamientoBurbuja);
        panel.add(botonOrdenamientoInsercion);
        panel.add(botonOrdenamientoSeleccion);
        panel.add(botonOrdenamientoShell);
        panel.add(botonOrdenamientoHeap);
        panel.add(botonOrdenamientoQuick);
        panel.add(new JScrollPane(areaSalida));

        add(panel);

        // Listeners para los botones
        botonGenerar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                generarArreglo();
            }
        });

        botonOrdenamientoBurbuja.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ordenarArreglo("burbuja");
            }
        });

        botonOrdenamientoInsercion.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ordenarArreglo("insercion");
            }
        });

        botonOrdenamientoSeleccion.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ordenarArreglo("seleccion");
            }
        });

        botonOrdenamientoShell.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ordenarArreglo("shell");
            }
        });

        botonOrdenamientoHeap.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ordenarArreglo("heap");
            }
        });

        botonOrdenamientoQuick.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ordenarArreglo("quick");
            }
        });
    }

    private void generarArreglo() {
        int tamano = Integer.parseInt(campoTamanoArreglo.getText());
        arreglo = new int[tamano];
        Random rand = new Random();
        for (int i = 0; i < tamano; i++) {
            arreglo[i] = rand.nextInt(100);  // Genera números entre 0 y 99
        }
        areaSalida.setText("Arreglo Generado: \n" + arregloToString(arreglo));
    }

    private void ordenarArreglo(String algoritmo) {
        if (arreglo == null || arreglo.length == 0) {
            areaSalida.setText("¡Por favor, genera un arreglo primero!");
            return;
        }

        int[] arregloOrdenado = arreglo.clone();
        long inicioTiempoMs = System.currentTimeMillis();
        long inicioTiempoNs = System.nanoTime();

        switch (algoritmo) {
            case "burbuja":
                SortingAlgorithms.bubbleSort(arregloOrdenado);
                break;
            case "insercion":
                SortingAlgorithms.insertionSort(arregloOrdenado);
                break;
            case "seleccion":
                SortingAlgorithms.selectionSort(arregloOrdenado);
                break;
            case "shell":
                SortingAlgorithms.shellSort(arregloOrdenado);
                break;
            case "heap":
                SortingAlgorithms.heapSort(arregloOrdenado);
                break;
            case "quick":
                SortingAlgorithms.quickSort(arregloOrdenado, 0, arregloOrdenado.length - 1);
                break;
        }

        long finTiempoMs = System.currentTimeMillis();
        long finTiempoNs = System.nanoTime();

        long duracionMs = finTiempoMs - inicioTiempoMs;
        long duracionNs = finTiempoNs - inicioTiempoNs;

        areaSalida.setText("Arreglo Original: \n" + arregloToString(arreglo) + "\n\nArreglo Ordenado (" + algoritmo + "): \n" + arregloToString(arregloOrdenado) +
                "\n\nTiempo de ejecución: " + duracionMs + " ms (" + duracionNs + " ns)");
    }

    private String arregloToString(int[] arr) {
        StringBuilder sb = new StringBuilder();
        for (int num : arr) {
            sb.append(num).append(" ");
        }
        return sb.toString();
    }
}
