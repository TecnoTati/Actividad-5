public class SortingApp {
    public static void main(String[] args) {
        // Iniciar la interfaz gráfica
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SortingGUI().setVisible(true);
            }
        });
    }
}


